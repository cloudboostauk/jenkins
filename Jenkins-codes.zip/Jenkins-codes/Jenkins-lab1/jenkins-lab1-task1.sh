#!/bin/bash
echo "My name is ${FirstName} ${LastName}"
echo "I am a ${Gender}"
